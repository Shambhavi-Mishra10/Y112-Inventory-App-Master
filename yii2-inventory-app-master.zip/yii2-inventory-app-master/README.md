Code Factory Indonesia
============================

Source code Aplikasi Inventory Sederhana ini merupakan pendukung tutorial yang ada di [PojokProgrammer](http://PojokProgrammer.net). Artikel tersebut terbagi dalam 5 bagian, yaitu

- [Part #1](http://pojokprogrammer.net/content/aplikasi-persediaan-barang-sistem-inventory-menggunakan-yii2-part-1) - Instalasi Yii
- [Part #2](http://pojokprogrammer.net/content/aplikasi-persediaan-barang-sistem-inventory-menggunakan-yii2-part-2) - Database dan Migration
- [Part #3](http://pojokprogrammer.net/content/aplikasi-persediaan-barang-sistem-inventory-menggunakan-yii2-part-3) - CRUD Master Barang
- [Part #4](http://pojokprogrammer.net/content/aplikasi-persediaan-barang-sistem-inventory-menggunakan-yii2-part-4) - CRUD Transaksi Barang
- [Part #5](http://pojokprogrammer.net/content/aplikasi-persediaan-barang-sistem-inventory-menggunakan-yii2-part-5) - Laporan Kartu Stok


Silakan gunakan source code ini untuk keperluan pembelajaran saja. Dilarang menggunakan source code ini untuk keperluan komersil tanpa izin tertulis yang resmi.
