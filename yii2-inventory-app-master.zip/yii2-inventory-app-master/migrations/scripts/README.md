# Sample Data

This folder contains scripts to create table structures, triggers, and some sample data. as per November 3th, 2020 there is only scripts for MySQL database available. Hopefully, next I can provide scripts for other database(s).

The order of execution should be
- tables.sql
- triggers.sql
- data.sql